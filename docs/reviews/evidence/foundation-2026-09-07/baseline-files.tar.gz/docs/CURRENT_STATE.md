# CURRENT STATE — 단일 복원 지점

갱신: 2026-09-07 · 실제 워커 파일 인수·Grok4개 동시 실행 사전 검증 완료. main / 15ff0139.
이번 요청: 다른 모델 워커와 본격 실행 준비가 충분한지 판단. 임시 작업 검증만 수행.
Opus/Grok 파일 작업 PASS, Grok4개 동시 작업 PASS. 프로젝트 작업·벤치 셀·에셋 생성·goal은 미착수.
기존 구현을 보존할 의무는 없지만 근거/실험 원본은 유지한다.

## 먼저 읽을 문서

- `docs/reviews/execution-readiness-2026-09-07.md` — 최신 판정: 구현 착수 가능, 전체 벤치 자동화는 첫 스프린트의 작업.
- `docs/reviews/runtime-access-preflight-2026-09-07.md` — 최신 브라우저/인증/격리 진단, goal 시작 경계.
- `docs/OMD_EXECUTION_PLAN_2026-09-07.md` — 최신 실행 기준: F/B/A/D/E, 모델/슬롯/완료 판정.
- `docs/OMD_EXECUTION_BOARD_2026-09-07.json` — 28개 계획 작업의 의존성·담당·완료 증거. 스케줄러 아님.
- `docs/reviews/omd-restart-audit-2026-09-07.md` — 코드 근거, 결함, 진척, 검증 결과.
- `docs/BENCHMARK_RESTART_2026-09-07.md` — 순정 포함 4조건 파일럿. 실행 전 초안.
- `docs/APHRODITE_REBOOT_2026-09-07.md` — 작품 브리프와 하네스 편입 조건. r10 미제작.
- `docs/APHRODITE_HANDOVER.md` — 이전 점수/도구/코퍼스. 상단의 인과 해석 보정 먼저 읽기.
- 이전 장문 상태 원문: `docs/archive/CURRENT_STATE-2026-09-07-before-audit.md`.
  오래된 실행 명령·승인 대기는 당시 기록이며 자동 재개 지시가 아니다.

## 확인된 현황

| 축 | 상태 |
|---|---|
| CLI | 소스 2.0.1. 제품 스킬 28 / Cursor 27. npm latest·실서비스 배포는 이번에 조회 안 함 |
| T3 | 레인 A 108개 생성, B 0. OMD 75.1 / UIUX 74.2 / Hallmark 68.9; 유의한 우승 없음, α 전 축 미달 |
| 순정 모델 | 기존 UI-Resolve에 no-skill 인프라 있음. 최근 T3 비교에는 없음 |
| Aphrodite | r0~r9. 최고 r2 70, r9 10, r7/r8 미채점. 새 미적 합격작 없음 |
| Core 이관 | staged DESIGN.md 290, DONE 293, deferred openpoint 1, ledger missing 0. 정본 440는 기존 형식 |
| 블로그 | 출시 글 1편 ko/en. 기업별 연재는 미생성 |
| GitHub | 조회 당시 open PR 0, open issue 21. 일부 열린 이슈는 현행 구현이 있어 acceptance 후 정리 필요 |

## 이번에 수정한 것 (미커밋)

1. doctor의 aphrodite 누락, 5개 언어 CLI 문서 목록/개수 불일치.
2. quality gate 기본 strict + prepublish strict. 빈 행렬/오타 selector/빈·알 수 없는 check/누락 source 차단.
   개발 진단만 `--allow-incomplete`. 정책 회귀 테스트 5개 추가.
3. 공식 mirror sync로 aphrodite 사본 2개 갱신. 최종 managed drift 0.
4. 캠페인 초안의 “OMD만 system.md 생성” 오정보 정정: 실제 세 arm 모두 제출.
5. 인수 감사/벤치/아프로디테 재시작안 작성, 이전 CURRENT_STATE 원문 아카이브.

## 검증

- CLI 전체: 1420 passed / 180 skipped (115 files passed, 20 skipped).
- 웹 전체: 891 passed (61 files).
- CLI build/lint, 웹 typecheck, diff whitespace PASS.
- tarball offline 설치 smoke 2개 PASS: 4채널 doctor + Autopilot HANDOFF + Core compile/adopt.
- mirror check: 200 managed, drift 0, overlay 98개 명시적 제외.
- quality gate의 missing karrot 2칸: BLOCKED, exit 1. 전체 시각 gate는 재실행 안 함.
- 브라우저 하네스 연결 실패(Chrome 연결 없음). 저장된 캡처로만 시각 검토; r9 live 미검증.
- 후속 계약: `test-asset-generation-contract.mjs` 17/17 PASS, draft validation PASS.
  calibration/main readiness는 미해결 상태로 exit1 확인. 실제 broker/생성 결과에 대한 PASS가 아님.
  신규 파일은 `benchmarks/ui-resolve-bench/config/asset-generation-four-arm-v0.1.json` 및 동명 검증/테스트 도구.

## 다음 실행 — 제안, 아직 산출/승인으로 간주하지 않기

1. Sol: F-0 snapshot→F-1 실제 runtime/model/브라우저 probe→F-2 설치 dependency→F-3 SHA receipt.
2. Opus 5 / Claude Code: F-1 확인 후 A-0 방향, D-0 evidence, E-0 기업 브리프를 개별 실행.
   Grok 4.6 / Grok Build: probe 후 A-1 에셋. Sol은 코드/통계/통합, Astra/Fable은 필요 시 기획만.
3. B-0~2: 기존 UI-Resolve에 4조건 portable adapter·격리 검증, calibration 4셀 후 동결.
   신규 계약은 작성/검증 완료. 다음은 F-1 cross-CLI discovery 격리→B-1 실제 broker/adapter→B-2 도구/에셋 calibration.
   B-3/4: Grok 4조건 병렬로 첫 제출36+후속12, 각 조건 자율 에셋 생성·공유 browser broker 1슬롯.
   B-5 에셋/페이지 별도 평가→B-6 우선 결함 수정/B-7 생성 에셋→페이지 비교 영상.
4. A-1/2 첫 화면+전환의 오너 채택→A-3 작품→A-4 스킬→A-5 다른 업종4회→A-6 출하 후보.
5. D: 4 canary 소비자 parity·실제 rollback 후 추가10개. E: D-0 근거 재사용, 2편 ko/en와 발행 후14일 학습.

## 실행 운영 결정

- 신규 검증: Opus/Grok 입력파일→출력파일→회수 PASS. Grok4개 별도 session/workspace 동시 실행4/4 PASS.
  `docs/reviews/evidence/worker-readiness-2026-09-07.json` 참조. media/브라우저가 아닌 작은 파일 작업 기준.
- F-1은 기본 워커/복구/브라우저 연결, B-1/B-2는 벤치 전용 broker/context/media admission. 순환 대기 금지.
- 이번 사용자 지시: 사전 점검 이후 실제 작업을 별도로 시작. active goal=null이며 아직 생성하지 않음.
- 프로젝트 AGENTS에 Computer Use Chrome 우선 기록. Chrome extension 연결/Imagine 로그인 확인; iTerm2는 CUA safety policy 거절.
- Claude auth sandbox false→host true(Max). safe-mode의 Opus5 실제 호출 성공. 재로그인 불필요.
- Grok 일반 진단과 임시 격리 프로필 진단 모두 성공. init grok-4.6/modelUsage grok-4.6-build, tools0회 사용.
- 빈 --tools 인자는 default tools가 남아 부적합. 임시 프로필+명시적 allowlist에서 skills0/tools=[todo_write] 실제 확인.
- Codex ChatGPT 로그인, 조회 당시 사용21%/잔여79%. 이전 Sol capacity는 auth 오류 아님; 이번 Sol 재호출 미실행.
- 평시 Sol1+Opus1, 필요할 때 Grok1 추가. 벤치 예외는 Grok4 병렬·공유 browser1슬롯, independent asset 도구 병렬 허용.
- 공통 크리에이티브 에셋 세트 제공을 철회. 공통 brief/facts/tool 권한만 제공하고 각 조건의 기획·생성·선택을 평가.
- 브라우저는 실제 broker로 FIFO/셀별 시야·다운로드 귀속/취소를 강제. 아직 broker live 구현/검증 전이며 문구만으로 완료 처리 금지.
- elapsed/실제 중단된 queue wait/active/browser/media 시간을 구분. 병렬 latency는 descriptive-only. 예산은 calibration 후 동결.
- 이번 사용자 지시가 모델 기준. 과거 Sol 퇴역 문구는 현행 허용 policy와 다르며 F-1에서 조정; 동결 epoch 보존.
- CLI help/version/설정 탐색·인증·파일 작업·4세션 기본 병렬 확인. media 생성/다운로드·broker·장시간 복구 검증은 남아 있음.
- 후속 F-1 읽기 전용 점검: temp cwd에서도 Grok가145skills/15hooks/6MCP를 발견.
  문서화된 GROK_HOME 분리 후에도 ~/.agents·~/.claude 경로에서122skills/14hooks/6MCP 발견.
  cwd/config 폴더 분리만으로 순정 격리 완료 아님. `docs/reviews/evidence/grok-parallel-preflight-2026-09-07/discovery-receipt.json` 참조.
  당시 provider 호출0. 이후 최신 사전 점검에서 실제 marker 호출과 명시적 allowlist 확인; 4세션/생성 미검증. 전역 사용자 설정 변경 안 함.
- 벤치 우승은 완료 필수 조건 아님. 작품 성공/스킬 재현성, 글 발행/성장 효과를 각각 분리 판정.
- 공통 코드/생성 파일/mirror/상태 문서는 Sol 통합 담당이 직렬 반영. 새 branch/Grok·Claude CLI 생성/발행은 아직 시작하지 않음.

## 유지할 경계 / 열려 있는 일

- 검사 PASS는 미적 우승이 아니다. 밝은 면·3D·에셋 수가 실패 원인이라는 인과 해석은 미확정.
- 마이그레이션은 wave54 경계 중단 기록 유지. 이 감사에서 STOP 제거/마라톤 재가동 안 함.
- 실행 스킬의 스타일 gate 개정과 자연어 aphrodite routing은 미실행. 새 작품 검증 후 편입.
- npm publish, 외부 포스팅, 새 벤치 생성, r10 제작은 이번 감사에서 실행하지 않음.
- 기존 사용자 변경: higgsgen/research/r5/scroll-feel.json 및 untracked wanted captures/r4 연구 JSON 보존.
- 런 디렉터리 삭제 금지. canonical references는 web/references만 편집하며 창작 제안을 공식 사실로 승격 금지.
